"""
Telegram Service - Python microservice for Telegram operations
Handles: login, group joining, broadcasting, session management
"""
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional
import os
from dotenv import load_dotenv
import asyncio
from telegram_manager import TelegramManager

load_dotenv()

app = FastAPI(title="Telegram Service", version="1.0.0")

# CORS - Next.js'ten gelen istekleri kabul et
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://localhost:3001"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Session yönetimi için dictionary
telegram_clients = {}


# Request/Response Models
class LoginRequest(BaseModel):
    phone: str
    api_id: int
    api_hash: str


class VerifyRequest(BaseModel):
    phone: str
    code: str


class JoinGroupsRequest(BaseModel):
    phone: str
    group_links: List[str]
    min_delay: int = 30
    max_delay: int = 60


class BroadcastRequest(BaseModel):
    phone: str
    group_links: List[str]
    message: str


class AccountInfoRequest(BaseModel):
    phone: str
    api_id: Optional[int] = None
    api_hash: Optional[str] = None


@app.get("/")
async def root():
    return {
        "service": "Telegram Service",
        "status": "running",
        "version": "1.0.0"
    }


@app.post("/telegram/login")
async def start_login(request: LoginRequest):
    """Telegram login başlat - kod gönder"""
    try:
        manager = TelegramManager(
            phone=request.phone,
            api_id=request.api_id,
            api_hash=request.api_hash
        )
        
        result = await manager.send_code()
        
        # Manager'ı sakla (verification için)
        telegram_clients[request.phone] = manager
        
        return {
            "success": True,
            "message": "Doğrulama kodu gönderildi",
            "phone": request.phone,
            "phone_code_hash": result.get("phone_code_hash")
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/telegram/verify")
async def verify_code(request: VerifyRequest):
    """Telegram kod doğrula ve giriş yap"""
    try:
        if request.phone not in telegram_clients:
            raise HTTPException(status_code=400, detail="Önce login endpoint'ini çağırın")
        
        manager = telegram_clients[request.phone]
        result = await manager.verify_code(request.code)
        
        return {
            "success": True,
            "message": "Giriş başarılı",
            "user": result
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/telegram/join-groups")
async def join_groups(request: JoinGroupsRequest):
    """Gruplara katıl - delay ile"""
    try:
        if request.phone not in telegram_clients:
            raise HTTPException(status_code=400, detail="Hesap giriş yapmamış")
        
        manager = telegram_clients[request.phone]
        results = await manager.join_groups(
            group_links=request.group_links,
            min_delay=request.min_delay,
            max_delay=request.max_delay
        )
        
        return {
            "success": True,
            "results": results
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/telegram/broadcast")
async def broadcast_message(request: BroadcastRequest):
    """Gruplara mesaj gönder"""
    try:
        if request.phone not in telegram_clients:
            raise HTTPException(status_code=400, detail="Hesap giriş yapmamış")
        
        manager = telegram_clients[request.phone]
        results = await manager.broadcast_message(
            group_links=request.group_links,
            message=request.message
        )
        
        return {
            "success": True,
            "results": results
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/telegram/account-info")
async def get_account_info(request: AccountInfoRequest):
    """Hesap bilgilerini al"""
    try:
        if request.phone not in telegram_clients:
            raise HTTPException(status_code=400, detail="Hesap giriş yapmamış")
        
        manager = telegram_clients[request.phone]
        info = await manager.get_account_info()
        
        return {
            "success": True,
            "info": info
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/telegram/get-joined-groups")
async def get_joined_groups(request: AccountInfoRequest):
    """Hesabın katıldığı grupları al"""
    try:
        # Eğer client yoksa session'dan yükle
        if request.phone not in telegram_clients:
            # Session dosyası var mı kontrol et
            sessions_dir = os.getenv("SESSIONS_DIR", "./sessions")
            session_file = os.path.join(sessions_dir, f"{request.phone}.session")
            
            if not os.path.exists(session_file):
                raise HTTPException(status_code=400, detail="Hesap bulunamadı. Lütfen önce giriş yapın.")
            
            if not request.api_id or not request.api_hash:
                raise HTTPException(status_code=400, detail="API credentials gerekli")
            
            # Session'dan yükle
            manager = TelegramManager(
                phone=request.phone,
                api_id=request.api_id,
                api_hash=request.api_hash
            )
            
            # Client'ı bağla (session dosyasından otomatik yükler)
            await manager.client.connect()
            
            if not await manager.client.is_user_authorized():
                raise HTTPException(status_code=400, detail="Session geçersiz. Lütfen tekrar giriş yapın.")
            
            telegram_clients[request.phone] = manager
        
        manager = telegram_clients[request.phone]
        groups = await manager.get_joined_groups()
        
        return {
            "success": True,
            "groups": groups
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/telegram/disconnect")
async def disconnect_account(request: AccountInfoRequest):
    """Hesabı kapat"""
    try:
        if request.phone in telegram_clients:
            manager = telegram_clients[request.phone]
            await manager.disconnect()
            del telegram_clients[request.phone]
        
        return {
            "success": True,
            "message": "Hesap kapatıldı"
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    host = os.getenv("HOST", "0.0.0.0")
    
    uvicorn.run(
        "main:app",
        host=host,
        port=port,
        reload=True
    )
