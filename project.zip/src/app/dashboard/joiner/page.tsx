"use client";

import { useState, useEffect, useRef } from "react";
import useSWR from "swr";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { GlassCard } from "@/components/ui/glass-card";
import {
    Plus,
    Trash2,
    Play,
    CheckCircle2,
    XCircle,
    Clock,
    Users,
    Loader2,
    Shield
} from "lucide-react";
import { toast } from "sonner";

const fetcher = (url: string) => fetch(url).then((res) => res.json());

type LogEntry = {
    timestamp: Date;
    account: string;
    group: string;
    type: 'success' | 'error' | 'info' | 'waiting';
    message: string;
};

export default function JoinerPage() {
    const [groupLinks, setGroupLinks] = useState("");
    const [joinQueue, setJoinQueue] = useState<string[]>([]);
    const [selectedAccountIds, setSelectedAccountIds] = useState<number[]>([]);
    const [isJoining, setIsJoining] = useState(false);
    const [joinDelay, setJoinDelay] = useState(30);
    const [randomDelay, setRandomDelay] = useState(15);
    const [maxGroupsPerAccount, setMaxGroupsPerAccount] = useState(50);

    // Live Terminal
    const [logs, setLogs] = useState<LogEntry[]>([]);
    const [stats, setStats] = useState({ total: 0, success: 0, failed: 0 });
    const logContainerRef = useRef<HTMLDivElement>(null);

    const { data: accounts = [] } = useSWR("/api/accounts", fetcher);

    // Auto-scroll logs
    useEffect(() => {
        if (logContainerRef.current) {
            logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
        }
    }, [logs]);

    const addLog = (account: string, group: string, type: LogEntry['type'], message: string) => {
        setLogs(prev => [...prev, {
            timestamp: new Date(),
            account,
            group,
            type,
            message
        }]);
    };

    const clearLogs = () => {
        setLogs([]);
        setStats({ total: 0, success: 0, failed: 0 });
    };

    const handleAddToQueue = () => {
        const links = groupLinks
            .split('\n')
            .map(line => line.trim())
            .filter(line => line.startsWith('https://t.me/') || line.startsWith('t.me/') || line.startsWith('@'))
            .map(line => {
                if (line.startsWith('@')) return `https://t.me/${line.substring(1)}`;
                if (line.startsWith('https://')) return line;
                return `https://${line}`;
            });

        if (links.length === 0) {
            toast.error("Please enter valid Telegram group links");
            return;
        }

        setJoinQueue(prev => [...new Set([...prev, ...links])]);
        setGroupLinks("");
        toast.success(`Added ${links.length} groups to queue`);
    };

    const handleClearQueue = () => {
        setJoinQueue([]);
        toast.success("Queue cleared");
    };

    const toggleAccount = (id: number) => {
        setSelectedAccountIds(prev =>
            prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
        );
    };

    const handleStartJoining = async () => {
        if (selectedAccountIds.length === 0) {
            toast.error("Please select at least one account");
            return;
        }

        if (joinQueue.length === 0) {
            toast.error("Please add groups to the queue");
            return;
        }

        setIsJoining(true);
        clearLogs();

        let totalSuccess = 0;
        let totalFailed = 0;
        let totalProcessed = 0;

        try {
            for (const accountId of selectedAccountIds) {
                const account = accounts.find((a: any) => a.id === accountId);
                if (!account) continue;

                addLog(account.phone, 'System', 'info', `🚀 Starting join process for ${account.phone}`);

                for (let i = 0; i < joinQueue.length && i < maxGroupsPerAccount; i++) {
                    const link = joinQueue[i];
                    totalProcessed++;

                    addLog(account.phone, link, 'info', `⏳ Attempting to join...`);

                    try {
                        const response = await fetch("/api/groups/join", {
                            method: "POST",
                            headers: { "Content-Type": "application/json" },
                            body: JSON.stringify({
                                accountIds: [accountId],
                                targetLinks: [link],
                                minDelay: joinDelay,
                                maxDelay: joinDelay + randomDelay,
                            }),
                        });

                        const result = await response.json();
                        const hasResults = response.ok && result.success && result.results?.[0]?.results;

                        if (hasResults) {
                            const groupResults = result.results[0].results;
                            const groupResult = groupResults[0]; // First (and only) group result

                            if (groupResult.status === "success") {
                                // Success - Add to account groups
                                await fetch(`/api/accounts/${accountId}/groups`, {
                                    method: "POST",
                                    headers: { "Content-Type": "application/json" },
                                    body: JSON.stringify({
                                        groups: [{
                                            link: link,
                                            name: groupResult.title || groupResult.link || "Unknown",
                                            username: groupResult.username,
                                            memberCount: groupResult.participants_count || 0,
                                            joinedAt: new Date().toISOString(),
                                        }]
                                    }),
                                });

                                totalSuccess++;
                                addLog(
                                    account.phone,
                                    link,
                                    'success',
                                    `✅ ${groupResult.message || 'Joined successfully'}`
                                );
                            } else {
                                // Error - Add to blacklist
                                totalFailed++;
                                const errorMsg = groupResult.message || "Unknown error";

                                addLog(account.phone, link, 'error', `❌ Failed: ${errorMsg}`);

                                // Auto-blacklist via API
                                try {
                                    await fetch(`/api/accounts/${account.phone}/blacklist`, {
                                        method: "POST",
                                        headers: { "Content-Type": "application/json" },
                                        body: JSON.stringify({
                                            link: link,
                                            reason: errorMsg,
                                            errorCode: groupResult.error_code,
                                        }),
                                    });
                                    addLog(account.phone, link, 'info', `🛡️ Added to blacklist`);
                                } catch (err) {
                                    console.error("Failed to blacklist:", err);
                                }
                            }

                            setStats({ total: totalProcessed, success: totalSuccess, failed: totalFailed });

                            // Apply delay (except for last group)
                            if (i < joinQueue.length - 1 && i < maxGroupsPerAccount - 1) {
                                const baseDelay = joinDelay * 1000;
                                const randomOffset = (Math.random() * randomDelay * 2 - randomDelay) * 1000;
                                const delay = Math.max(1000, baseDelay + randomOffset);
                                const delaySec = Math.round(delay / 1000);

                                addLog(account.phone, link, 'waiting', `⏳ Waiting ${delaySec} seconds...`);
                                await new Promise(resolve => setTimeout(resolve, delay));
                            }
                        } else {
                            // No results from API
                            totalFailed++;
                            addLog(account.phone, link, 'error', `❌ Failed: ${result.error || 'No response'}`);
                            setStats({ total: totalProcessed, success: totalSuccess, failed: totalFailed });
                        }
                    } catch (error: any) {
                        totalFailed++;
                        addLog(account.phone, link, 'error', `❌ Error: ${error.message}`);
                        setStats({ total: totalProcessed, success: totalSuccess, failed: totalFailed });
                    }
                }

                addLog(account.phone, 'System', 'info', `✅ Completed for ${account.phone}`);
            }

            toast.success(`Joining completed! ${totalSuccess} success, ${totalFailed} failed`);
            setJoinQueue([]);

        } catch (error: any) {
            console.error("Failed to join groups:", error);
            toast.error(`Error: ${error.message}`);
        } finally {
            setIsJoining(false);
        }
    };

    return (
        <div className="container mx-auto space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900 dark:text-white flex items-center gap-3">
                        <Users className="h-8 w-8 text-blue-500" />
                        Group Joiner
                    </h1>
                    <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">
                        Join Telegram groups with multiple accounts
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Left Column - Queue & Settings */}
                <div className="space-y-6">
                    {/* Add Groups */}
                    <GlassCard className="p-6">
                        <h3 className="font-semibold text-gray-900 dark:text-white mb-4">
                            Add Groups to Queue
                        </h3>
                        <div className="space-y-4">
                            <Textarea
                                value={groupLinks}
                                onChange={(e) => setGroupLinks(e.target.value)}
                                placeholder="Paste group links (one per line):&#10;https://t.me/group1&#10;@groupusername&#10;https://t.me/group2"
                                className="min-h-[150px] font-mono text-sm"
                                disabled={isJoining}
                            />
                            <Button onClick={handleAddToQueue} className="w-full" disabled={isJoining}>
                                <Plus className="h-4 w-4 mr-2" />
                                Add to Queue ({joinQueue.length})
                            </Button>
                        </div>
                    </GlassCard>

                    {/* Join Settings */}
                    <GlassCard className="p-6">
                        <h3 className="font-semibold text-gray-900 dark:text-white mb-4">
                            Join Settings
                        </h3>
                        <div className="grid grid-cols-3 gap-4 mb-4">
                            <div>
                                <label className="text-xs text-gray-600 dark:text-gray-400 mb-1 block">
                                    Delay (sec)
                                </label>
                                <Input
                                    type="number"
                                    value={joinDelay}
                                    onChange={(e) => setJoinDelay(parseInt(e.target.value) || 30)}
                                    min="1"
                                    disabled={isJoining}
                                />
                            </div>
                            <div>
                                <label className="text-xs text-gray-600 dark:text-gray-400 mb-1 block">
                                    Random (±sec)
                                </label>
                                <Input
                                    type="number"
                                    value={randomDelay}
                                    onChange={(e) => setRandomDelay(parseInt(e.target.value) || 15)}
                                    min="0"
                                    disabled={isJoining}
                                />
                            </div>
                            <div>
                                <label className="text-xs text-gray-600 dark:text-gray-400 mb-1 block">
                                    Max/Account
                                </label>
                                <Input
                                    type="number"
                                    value={maxGroupsPerAccount}
                                    onChange={(e) => setMaxGroupsPerAccount(parseInt(e.target.value) || 50)}
                                    min="1"
                                    disabled={isJoining}
                                />
                            </div>
                        </div>
                    </GlassCard>

                    {/* Account Selection */}
                    <GlassCard className="p-6">
                        <h3 className="font-semibold text-gray-900 dark:text-white mb-4">
                            Select Accounts ({selectedAccountIds.length})
                        </h3>
                        <div className="flex gap-2 flex-wrap">
                            {accounts.length === 0 ? (
                                <p className="text-sm text-gray-500">No accounts available</p>
                            ) : (
                                accounts.map((acc: any) => (
                                    <Button
                                        key={acc.id}
                                        variant={selectedAccountIds.includes(acc.id) ? "default" : "outline"}
                                        size="sm"
                                        onClick={() => toggleAccount(acc.id)}
                                        disabled={isJoining}
                                    >
                                        {acc.phone}
                                    </Button>
                                ))
                            )}
                        </div>
                        <Button
                            onClick={handleStartJoining}
                            disabled={isJoining || selectedAccountIds.length === 0 || joinQueue.length === 0}
                            className="w-full mt-4"
                        >
                            {isJoining ? (
                                <>
                                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                                    Joining...
                                </>
                            ) : (
                                <>
                                    <Play className="h-4 w-4 mr-2" />
                                    Start Joining ({selectedAccountIds.length} accounts, {joinQueue.length} groups)
                                </>
                            )}
                        </Button>
                    </GlassCard>
                </div>

                {/* Right Column - Live Terminal */}
                <div className="space-y-6">
                    {/* Statistics */}
                    {(stats.total > 0 || isJoining) && (
                        <GlassCard className="p-4">
                            <div className="grid grid-cols-3 gap-4 text-center">
                                <div>
                                    <div className="text-2xl font-bold text-gray-900 dark:text-white">
                                        {stats.total}
                                    </div>
                                    <div className="text-xs text-gray-500">Total</div>
                                </div>
                                <div>
                                    <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                                        {stats.success}
                                    </div>
                                    <div className="text-xs text-gray-500">Success</div>
                                </div>
                                <div>
                                    <div className="text-2xl font-bold text-red-600 dark:text-red-400">
                                        {stats.failed}
                                    </div>
                                    <div className="text-xs text-gray-500">Failed</div>
                                </div>
                            </div>
                        </GlassCard>
                    )}

                    {/* Live Terminal */}
                    <GlassCard className="p-6">
                        <div className="flex items-center justify-between mb-4">
                            <h3 className="font-semibold text-gray-900 dark:text-white flex items-center gap-2">
                                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                                Live Terminal
                            </h3>
                            {logs.length > 0 && (
                                <Button variant="ghost" size="sm" onClick={clearLogs}>
                                    <Trash2 className="h-3 w-3 mr-1" />
                                    Clear
                                </Button>
                            )}
                        </div>

                        <div
                            ref={logContainerRef}
                            className="bg-gray-950 rounded-lg p-4 h-[500px] overflow-y-auto font-mono text-xs"
                        >
                            {logs.length === 0 ? (
                                <div className="text-gray-500 text-center py-8">
                                    No activity yet. Start joining to see logs here.
                                </div>
                            ) : (
                                logs.map((log, idx) => (
                                    <div
                                        key={idx}
                                        className={`mb-2 ${log.type === 'success' ? 'text-green-400' :
                                                log.type === 'error' ? 'text-red-400' :
                                                    log.type === 'waiting' ? 'text-yellow-400' :
                                                        'text-blue-400'
                                            }`}
                                    >
                                        <span className="text-gray-500">
                                            [{log.timestamp.toLocaleTimeString()}]
                                        </span>
                                        {' '}
                                        <span className="text-gray-400">[{log.account}]</span>
                                        {' '}
                                        {log.message}
                                    </div>
                                ))
                            )}
                        </div>
                    </GlassCard>

                    {/* Queue Preview */}
                    {joinQueue.length > 0 && (
                        <GlassCard className="p-4">
                            <div className="flex items-center justify-between mb-2">
                                <h4 className="text-sm font-semibold text-gray-900 dark:text-white">
                                    Queue ({joinQueue.length})
                                </h4>
                                <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={handleClearQueue}
                                    disabled={isJoining}
                                >
                                    <Trash2 className="h-3 w-3" />
                                </Button>
                            </div>
                            <div className="text-xs text-gray-500 space-y-1 max-h-32 overflow-y-auto">
                                {joinQueue.slice(0, 5).map((link, idx) => (
                                    <div key={idx} className="truncate">• {link}</div>
                                ))}
                                {joinQueue.length > 5 && (
                                    <div className="text-gray-400">... and {joinQueue.length - 5} more</div>
                                )}
                            </div>
                        </GlassCard>
                    )}
                </div>
            </div>
        </div>
    );
}
