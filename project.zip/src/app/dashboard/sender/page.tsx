"use client";

import { useState, useEffect, useRef } from "react";
import useSWR from "swr";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { GlassCard } from "@/components/ui/glass-card";
import {
    Dialog,
    DialogContent,
    DialogHeader,
    DialogTitle,
} from "@/components/ui/dialog";
import {
    Send,
    Play,
    Pause,
    Download,
    Upload,
    RefreshCw,
    Users,
    Search,
    CheckCircle2,
    X,
    Save,
    Plus
} from "lucide-react";
import { toast } from "sonner";

const fetcher = (url: string) => fetch(url).then((res) => res.json());

// Account button with individual group count
function AccountButton({ acc, selectedAccountId, onSelect }: any) {
    const { data: groupsData } = useSWR(
        `/api/accounts/${acc.id}/groups`,
        fetcher,
        { refreshInterval: 10000 }
    );

    const groupCount = Array.isArray(groupsData) ? groupsData.length : 0;

    return (
        <Button
            variant={selectedAccountId === acc.id ? "default" : "outline"}
            size="sm"
            onClick={onSelect}
            className="relative"
        >
            {selectedAccountId === acc.id && (
                <CheckCircle2 className="h-3 w-3 mr-1" />
            )}
            {acc.phone}
            <Badge variant="secondary" className="ml-2 text-[10px]">
                {groupCount} groups
            </Badge>
        </Button>
    );
}

export default function SenderPage() {
    const [message, setMessage] = useState("");
    const [selectedAccountId, setSelectedAccountId] = useState<number | null>(null);
    const [selectedGroupIds, setSelectedGroupIds] = useState<number[]>([]);
    const [isSending, setIsSending] = useState(false);
    const [isImporting, setIsImporting] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");
    const [messagesSent, setMessagesSent] = useState(0);
    const [isSchedulerRunning, setIsSchedulerRunning] = useState(false);
    const [nextBroadcast, setNextBroadcast] = useState<Date | null>(null);

    // Scheduler settings
    const [loopInterval, setLoopInterval] = useState(60); // minutes
    const [minDelay, setMinDelay] = useState(30); // seconds
    const [maxDelay, setMaxDelay] = useState(60); // seconds

    // Dialog states
    const [showSaveDialog, setShowSaveDialog] = useState(false);
    const [templateName, setTemplateName] = useState("");
    const [showSchedulerDetails, setShowSchedulerDetails] = useState(false);

    // Message Templates
    const [selectedTemplateId, setSelectedTemplateId] = useState<number | null>(null);

    // Live terminal logs
    interface BroadcastLog {
        id: number;
        timestamp: Date;
        group: string;
        status: 'sending' | 'success' | 'error';
        message: string;
    }
    const [broadcastLogs, setBroadcastLogs] = useState<BroadcastLog[]>([]);
    const logContainerRef = useRef<HTMLDivElement>(null);

    const schedulerIntervalRef = useRef<NodeJS.Timeout | null>(null);

    const { data: accounts = [] } = useSWR("/api/accounts", fetcher);
    const { data: groupsData, mutate: mutateGroups } = useSWR(
        selectedAccountId ? `/api/accounts/${selectedAccountId}/groups` : null,
        fetcher,
        { refreshInterval: 10000 }
    );
    const { data: messagesData, mutate: mutateMessages } = useSWR(
        selectedAccountId ? `/api/accounts/${selectedAccountId}/messages` : null,
        fetcher
    );

    // Ensure accountGroups and messages are always arrays
    const accountGroups = Array.isArray(groupsData) ? groupsData : [];
    const savedMessages = Array.isArray(messagesData) ? messagesData : [];

    // Countdown state for next broadcast
    const [countdown, setCountdown] = useState<string>("");

    // Auto-select first account if none selected
    useEffect(() => {
        if (accounts.length > 0 && !selectedAccountId) {
            setSelectedAccountId(accounts[0].id);
        }
    }, [accounts, selectedAccountId]);

    // Live countdown timer
    useEffect(() => {
        if (!isSchedulerRunning || !nextBroadcast) {
            setCountdown("");
            return;
        }

        const updateCountdown = () => {
            const now = new Date().getTime();
            const target = new Date(nextBroadcast).getTime();
            const diff = target - now;

            if (diff <= 0) {
                setCountdown("Starting...");
                return;
            }

            const minutes = Math.floor(diff / 60000);
            const seconds = Math.floor((diff % 60000) / 1000);
            setCountdown(`${minutes}:${seconds.toString().padStart(2, '0')}`);
        };

        // Update immediately
        updateCountdown();

        // Update every second
        const interval = setInterval(updateCountdown, 1000);

        return () => clearInterval(interval);
    }, [isSchedulerRunning, nextBroadcast]);

    // Auto-scroll logs
    useEffect(() => {
        if (logContainerRef.current) {
            logContainerRef.current.scrollTop = logContainerRef.current.scrollHeight;
        }
    }, [broadcastLogs]);

    const addLog = (group: string, status: 'sending' | 'success' | 'error', msg: string) => {
        const newLog: BroadcastLog = {
            id: Date.now(),
            timestamp: new Date(),
            group,
            status,
            message: msg
        };
        setBroadcastLogs(prev => [...prev.slice(-99), newLog]); // Keep last 100 logs
    };

    // Cleanup scheduler
    useEffect(() => {
        return () => {
            if (schedulerIntervalRef.current) {
                clearInterval(schedulerIntervalRef.current);
            }
        };
    }, []);

    const handleSend = async () => {
        if (!message.trim()) {
            toast.error("Please enter a message");
            return;
        }

        if (!selectedAccountId) {
            toast.error("Please select an account");
            return;
        }

        if (selectedGroupIds.length === 0) {
            toast.error("Please select at least one group");
            return;
        }

        setIsSending(true);

        try {
            const selectedGroups = accountGroups.filter((g: any) =>
                selectedGroupIds.includes(g.id)
            );
            const groupLinks = selectedGroups.map((g: any) => g.groupLink);

            // Log start
            addLog('System', 'sending', `Starting broadcast to ${groupLinks.length} groups...`);

            const response = await fetch("/api/groups/broadcast", {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    accountIds: [selectedAccountId],
                    targetLinks: groupLinks,
                    message: message,
                    minDelay: minDelay,  // Send delay settings
                    maxDelay: maxDelay   // Send delay settings
                }),
            });

            if (!response.ok) {
                const error = await response.json();
                addLog('System', 'error', `Broadcast failed: ${error.error}`);
                throw new Error(error.error || "Failed to broadcast");
            }

            const result = await response.json();
            console.log("Broadcast result:", result);

            // Log each group result INCLUDING waiting status
            if (result.results && result.results[0]?.results) {
                result.results[0].results.forEach((r: any) => {
                    if (r.status === 'waiting') {
                        // Show waiting delay
                        addLog(r.group_name || 'System', 'sending', r.message);
                    } else {
                        const status = r.status === 'success' ? 'success' : 'error';
                        addLog(r.group_name || r.link, status, r.message);
                    }
                });
            }

            setMessagesSent(prev => prev + groupLinks.length);
            addLog('System', 'success', `Broadcast completed! Sent to ${groupLinks.length} groups`);
            toast.success(`Successfully broadcasted to ${groupLinks.length} groups!`, {
                description: `Message sent to all selected groups`,
                duration: 4000,
            });

        } catch (error: any) {
            console.error("Failed to send:", error);
            addLog('System', 'error', error.message);
            toast.error("Broadcast failed", {
                description: error.message,
                duration: 5000,
            });
        } finally {
            setIsSending(false);
        }
    };

    const handleStartScheduler = () => {
        if (!message.trim() || !selectedAccountId || selectedGroupIds.length === 0) {
            toast.error("Please set message, account, and groups first");
            return;
        }

        setIsSchedulerRunning(true);
        setMessagesSent(0);

        const intervalMs = loopInterval * 60 * 1000;

        // Send immediately
        handleSend();

        // Schedule next broadcast
        const next = new Date(Date.now() + intervalMs);
        setNextBroadcast(next);

        // Set up recurring broadcast
        schedulerIntervalRef.current = setInterval(async () => {
            await handleSend();
            const nextTime = new Date(Date.now() + intervalMs);
            setNextBroadcast(nextTime);
        }, intervalMs);
    };

    const handleStopScheduler = () => {
        if (schedulerIntervalRef.current) {
            clearInterval(schedulerIntervalRef.current);
            schedulerIntervalRef.current = null;
        }
        setIsSchedulerRunning(false);
        setNextBroadcast(null);
    };

    const handleImportGroups = async () => {
        if (!selectedAccountId) {
            toast.error("Please select an account first");
            return;
        }

        setIsImporting(true);

        try {
            const response = await fetch(`/api/accounts/${selectedAccountId}/groups/import`, {
                method: "POST",
            });

            if (!response.ok) {
                const error = await response.json();
                throw new Error(error.error || "Failed to import groups");
            }

            const result = await response.json();
            mutateGroups();

            toast.success(`Successfully imported ${result.imported} groups!`, {
                description: `All groups have been imported and are ready to use`,
                duration: 5000,
            });
        } catch (error: any) {
            console.error("Failed to import groups:", error);
            toast.error("Import failed", {
                description: error.message,
                duration: 5000,
            });
        } finally {
            setIsImporting(false);
        }
    };

    // Template Management Functions
    const handleSaveTemplate = async () => {
        if (!templateName.trim() || !message.trim() || !selectedAccountId) {
            toast.error("Please enter a template name and message");
            return;
        }

        try {
            await fetch(`/api/accounts/${selectedAccountId}/messages`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    name: templateName,
                    content: message,
                }),
            });

            await mutateMessages();
            setShowSaveDialog(false);
            setTemplateName("");
            toast.success("Template saved successfully!");
        } catch (error: any) {
            toast.error("Failed to save template");
        }
    };

    const handleLoadTemplate = async (templateId: number, content: string) => {
        setMessage(content);
        setSelectedTemplateId(templateId);

        try {
            await fetch(`/api/accounts/${selectedAccountId}/messages`, {
                method: "PUT",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    messageId: templateId,
                    incrementUsage: true,
                }),
            });
            await mutateMessages();
            toast.success("Template loaded!");
        } catch (error) {
            console.error("Failed to update template usage:", error);
        }
    };

    const handleDeleteTemplate = async (templateId: number) => {
        try {
            await fetch(`/api/accounts/${selectedAccountId}/messages?messageId=${templateId}`, {
                method: "DELETE",
            });
            await mutateMessages();
            toast.success("Template deleted!");
        } catch (error) {
            toast.error("Failed to delete template");
        }
    };


    const toggleGroup = (id: number) => {
        setSelectedGroupIds(prev =>
            prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
        );
    };

    const toggleAllGroups = () => {
        if (selectedGroupIds.length === accountGroups.length) {
            setSelectedGroupIds([]);
        } else {
            setSelectedGroupIds(accountGroups.map((g: any) => g.id));
        }
    };

    const filteredGroups = accountGroups.filter((group: any) => {
        if (!searchTerm) return true;
        const query = searchTerm.toLowerCase();
        return (
            group.groupLink?.toLowerCase().includes(query) ||
            group.groupName?.toLowerCase().includes(query) ||
            group.groupUsername?.toLowerCase().includes(query)
        );
    });

    const selectedAccount = accounts.find((a: any) => a.id === selectedAccountId);

    return (
        <div className="container mx-auto space-y-6">
            <div className="flex items-center justify-between">
                <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                    Sender / Broadcaster
                </h1>
                <Button
                    variant="outline"
                    onClick={() => window.location.href = '/dashboard/templates'}
                >
                    <Save className="h-4 w-4 mr-2" />
                    Templates
                </Button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Left Column - Message Composer & Terminal */}
                <div className="space-y-6">
                    {/* Message Composer */}
                    <GlassCard className="p-6">
                        <div className="flex items-center gap-2 mb-4">
                            <Send className="h-5 w-5 text-blue-500" />
                            <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                                Message Composer
                            </h2>
                        </div>
                        <Textarea
                            placeholder="Type your message here..."
                            value={message}
                            onChange={(e) => setMessage(e.target.value)}
                            className="min-h-[120px] resize-none"
                        />

                        {/* Save Template Button */}
                        <div className="mt-4">
                            {!showSaveDialog ? (
                                <Button
                                    variant="outline"
                                    size="sm"
                                    onClick={() => setShowSaveDialog(true)}
                                    disabled={!message.trim()}
                                >
                                    <Save className="h-3 w-3 mr-1" />
                                    Save as Template
                                </Button>
                            ) : (
                                <div className="flex gap-2">
                                    <Input
                                        placeholder="Template name..."
                                        value={templateName}
                                        onChange={(e) => setTemplateName(e.target.value)}
                                        className="h-8"
                                        onKeyPress={(e) => e.key === 'Enter' && handleSaveTemplate()}
                                    />
                                    <Button size="sm" onClick={handleSaveTemplate} className="h-8">
                                        Save
                                    </Button>
                                    <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => {
                                            setShowSaveDialog(false);
                                            setTemplateName("");
                                        }}
                                        className="h-8"
                                    >
                                        Cancel
                                    </Button>
                                </div>
                            )}
                        </div>

                        <div className="mt-4 flex gap-2">
                            <Button
                                onClick={handleSend}
                                disabled={isSending || !message.trim() || selectedGroupIds.length === 0}
                                className="flex-1"
                            >
                                {isSending ? (
                                    <>
                                        <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
                                        Sending...
                                    </>
                                ) : (
                                    <>
                                        <Send className="mr-2 h-4 w-4" />
                                        Send Now ({selectedGroupIds.length} groups)
                                    </>
                                )}
                            </Button>
                        </div>
                    </GlassCard>

                    {/* Live Terminal */}
                    <GlassCard className="p-6">
                        <div className="flex items-center justify-between mb-4">
                            <div className="flex items-center gap-2">
                                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                                    Live Terminal
                                </h2>
                            </div>
                            {broadcastLogs.length > 0 && (
                                <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => setBroadcastLogs([])}
                                >
                                    Clear
                                </Button>
                            )}
                        </div>
                        <div
                            ref={logContainerRef}
                            className="bg-gray-900 dark:bg-black rounded-lg p-4 h-[400px] overflow-y-auto font-mono text-sm space-y-1"
                        >
                            {broadcastLogs.length === 0 ? (
                                <div className="text-gray-500 text-center py-8">
                                    No broadcast activity yet. Send a message to see logs here.
                                </div>
                            ) : (
                                broadcastLogs.map((log) => {
                                    const getStatusColor = () => {
                                        switch (log.status) {
                                            case 'success': return 'text-green-400';
                                            case 'error': return 'text-red-400';
                                            case 'sending': return 'text-yellow-400';
                                            default: return 'text-gray-400';
                                        }
                                    };

                                    const getStatusIcon = () => {
                                        switch (log.status) {
                                            case 'success': return '✓';
                                            case 'error': return '✗';
                                            case 'sending': return '⟳';
                                            default: return '•';
                                        }
                                    };

                                    return (
                                        <div key={log.id} className="flex gap-2 text-xs">
                                            <span className="text-gray-500 shrink-0">
                                                [{log.timestamp.toLocaleTimeString()}]
                                            </span>
                                            <span className={`${getStatusColor()} shrink-0`}>
                                                {getStatusIcon()}
                                            </span>
                                            <span className="text-gray-400 shrink-0 min-w-[120px] truncate" title={log.group}>
                                                {log.group}:
                                            </span>
                                            <span className="text-gray-200">
                                                {log.message}
                                            </span>
                                        </div>
                                    );
                                })
                            )}
                        </div>
                    </GlassCard>
                </div>

                {/* Right Column - Account Selection, Scheduler & Groups */}
                <div className="space-y-6">

                    {/* Account Tabs */}
                    <GlassCard className="p-4">
                        <div className="flex items-center gap-2 mb-2">
                            <Users className="h-4 w-4 text-blue-500" />
                            <span className="text-sm font-semibold text-gray-700 dark:text-gray-300">Select Account</span>
                        </div>
                        <div className="flex gap-2 flex-wrap">
                            {accounts.length === 0 ? (
                                <p className="text-sm text-gray-500">No accounts available</p>
                            ) : (
                                accounts.map((acc: any) => (
                                    <AccountButton
                                        key={acc.id}
                                        acc={acc}
                                        selectedAccountId={selectedAccountId}
                                        onSelect={() => {
                                            setSelectedAccountId(acc.id);
                                            setSelectedGroupIds([]);
                                        }}
                                    />
                                ))
                            )}
                        </div>
                    </GlassCard>

                    {/* Scheduler Status */}
                    {isSchedulerRunning && (
                        <GlassCard
                            className="p-4 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800 cursor-pointer hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors"
                            onClick={() => setShowSchedulerDetails(true)}
                        >
                            <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                    <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                                    <div>
                                        <div className="text-sm font-semibold text-blue-900 dark:text-blue-100 flex items-center gap-2">
                                            Scheduler Running
                                            <Badge variant="secondary" className="bg-blue-200 dark:bg-blue-800 text-blue-900 dark:text-blue-100">
                                                {accounts.find((a: any) => a.id === selectedAccountId)?.phone || "Unknown"}
                                            </Badge>
                                        </div>
                                        <div className="text-xs text-blue-700 dark:text-blue-300 mt-0.5 flex items-center gap-2">
                                            <span>Next broadcast in:</span>
                                            <span className="font-mono font-bold text-lg">
                                                {countdown || "Calculating..."}
                                            </span>
                                        </div>
                                        <div className="text-[10px] text-blue-600 dark:text-blue-400 mt-1">
                                            {selectedGroupIds.length} groups • Loop: {loopInterval}min • Delay: {minDelay}-{maxDelay}s
                                        </div>
                                    </div>
                                </div>
                                <Button
                                    variant="destructive"
                                    size="sm"
                                    onClick={(e) => {
                                        e.stopPropagation();
                                        handleStopScheduler();
                                    }}
                                >
                                    <Pause className="h-4 w-4 mr-2" />
                                    Stop
                                </Button>
                            </div>
                        </GlassCard>
                    )}

                    {/* Scheduler Settings */}
                    <GlassCard className="p-4">
                        <h3 className="font-semibold text-gray-900 dark:text-white mb-4">
                            Scheduler Settings
                        </h3>
                        <div className="grid grid-cols-3 gap-4 mb-4">
                            <div>
                                <label className="text-xs text-gray-600 dark:text-gray-400 mb-1 block">
                                    Loop (min)
                                </label>
                                <Input
                                    type="number"
                                    value={loopInterval}
                                    onChange={(e) => setLoopInterval(parseInt(e.target.value) || 60)}
                                    min="1"
                                    className="h-9"
                                />
                            </div>
                            <div>
                                <label className="text-xs text-gray-600 dark:text-gray-400 mb-1 block">
                                    Min Delay (s)
                                </label>
                                <Input
                                    type="number"
                                    value={minDelay}
                                    onChange={(e) => setMinDelay(parseInt(e.target.value) || 30)}
                                    min="1"
                                    className="h-9"
                                />
                            </div>
                            <div>
                                <label className="text-xs text-gray-600 dark:text-gray-400 mb-1 block">
                                    Max Delay (s)
                                </label>
                                <Input
                                    type="number"
                                    value={maxDelay}
                                    onChange={(e) => setMaxDelay(parseInt(e.target.value) || 60)}
                                    min="1"
                                    className="h-9"
                                />
                            </div>
                        </div>
                        <div className="flex gap-2">
                            <Button
                                onClick={handleStartScheduler}
                                disabled={isSchedulerRunning || !message.trim() || !selectedAccountId}
                                className="flex-1"
                            >
                                <Play className="h-4 w-4 mr-2" />
                                Start Scheduler
                            </Button>
                        </div>
                    </GlassCard>


                    {/* Groups Section */}

                    <GlassCard className="p-0 overflow-hidden flex flex-col max-h-[700px]">
                        <div className="p-4 border-b border-gray-100 dark:border-white/5 space-y-4">
                            <div className="flex items-center justify-between">
                                <h3 className="font-semibold text-gray-900 dark:text-white">
                                    {selectedAccount?.phone || "Select Account"}'s Groups
                                </h3>
                                <div className="flex gap-2">
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={handleImportGroups}
                                        disabled={isImporting || !selectedAccountId}
                                    >
                                        <RefreshCw className={`h-3 w-3 mr-1 ${isImporting ? 'animate-spin' : ''}`} />
                                        Import
                                    </Button>
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={toggleAllGroups}
                                        disabled={!selectedAccountId || accountGroups.length === 0}
                                    >
                                        {selectedGroupIds.length === accountGroups.length ? "Deselect All" : "Select All"}
                                    </Button>
                                </div>
                            </div>
                            <div className="relative">
                                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-500" />
                                <Input
                                    placeholder="Search groups..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="pl-10 h-9"
                                />
                            </div>
                            <div className="text-xs text-gray-500">
                                {selectedGroupIds.length} of {filteredGroups.length} selected
                            </div>
                        </div>

                        <div className="flex-1 overflow-y-auto p-4 space-y-2">
                            {!selectedAccountId ? (
                                <p className="text-sm text-gray-500 text-center py-8">
                                    Select an account to see its groups
                                </p>
                            ) : filteredGroups.length === 0 ? (
                                <div className="text-center py-8">
                                    <p className="text-sm text-gray-500 mb-3">
                                        No groups found
                                    </p>
                                    <Button
                                        variant="outline"
                                        size="sm"
                                        onClick={handleImportGroups}
                                        disabled={isImporting}
                                    >
                                        <RefreshCw className={`h-3 w-3 mr-1 ${isImporting ? 'animate-spin' : ''}`} />
                                        Import Groups
                                    </Button>
                                </div>
                            ) : (
                                filteredGroups.map((group: any) => (
                                    <div
                                        key={group.id}
                                        className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 dark:hover:bg-white/5 transition-colors"
                                    >
                                        <Checkbox
                                            id={`group-${group.id}`}
                                            checked={selectedGroupIds.includes(group.id)}
                                            onCheckedChange={() => toggleGroup(group.id)}
                                        />
                                        <div className="flex-1 min-w-0">
                                            <label
                                                htmlFor={`group-${group.id}`}
                                                className="text-sm font-medium text-gray-900 dark:text-white block cursor-pointer truncate"
                                            >
                                                {group.groupName || group.groupLink}
                                            </label>
                                            <div className="flex items-center gap-2 text-xs text-gray-500">
                                                {group.groupUsername && (
                                                    <span>@{group.groupUsername}</span>
                                                )}
                                                {group.memberCount && (
                                                    <span>• {group.memberCount.toLocaleString()} members</span>
                                                )}
                                            </div>
                                        </div>
                                        <Badge
                                            variant="outline"
                                            className="text-[10px] shrink-0"
                                        >
                                            {group.status}
                                        </Badge>
                                    </div>
                                ))
                            )}
                        </div>
                    </GlassCard>
                </div>
            </div>

            {/* Scheduler Details Modal */}
            <Dialog open={showSchedulerDetails} onOpenChange={setShowSchedulerDetails}>
                <DialogContent className="max-w-2xl">
                    <DialogHeader>
                        <DialogTitle className="flex items-center gap-2">
                            <div className="w-3 h-3 bg-green-500 rounded-full animate-pulse" />
                            Scheduler Details
                        </DialogTitle>
                    </DialogHeader>

                    <div className="space-y-4">
                        {/* Account Info */}
                        <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                            <div className="text-xs text-gray-500 dark:text-gray-400 mb-1">Active Account</div>
                            <div className="text-lg font-semibold text-gray-900 dark:text-white">
                                {accounts.find((a: any) => a.id === selectedAccountId)?.phone || "Unknown"}
                            </div>
                        </div>

                        {/* Target Groups */}
                        <div>
                            <div className="text-sm font-semibold text-gray-900 dark:text-white mb-2">
                                Target Groups ({selectedGroupIds.length})
                            </div>
                            <div className="max-h-40 overflow-y-auto space-y-1 p-2 bg-gray-50 dark:bg-gray-900 rounded-lg">
                                {accountGroups
                                    .filter((g: any) => selectedGroupIds.includes(g.id))
                                    .map((group: any) => (
                                        <div
                                            key={group.id}
                                            className="text-xs text-gray-700 dark:text-gray-300 flex items-center gap-2"
                                        >
                                            <Badge variant="secondary" className="text-[10px]">
                                                {group.status}
                                            </Badge>
                                            {group.groupName}
                                        </div>
                                    ))}
                            </div>
                        </div>

                        {/* Message Preview */}
                        <div>
                            <div className="text-sm font-semibold text-gray-900 dark:text-white mb-2">
                                Message
                            </div>
                            <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-lg text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap max-h-32 overflow-y-auto">
                                {message || "No message set"}
                            </div>
                        </div>

                        {/* Settings */}
                        <div className="grid grid-cols-3 gap-4">
                            <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
                                <div className="text-xs text-gray-500 dark:text-gray-400">Loop Interval</div>
                                <div className="text-lg font-semibold text-gray-900 dark:text-white">
                                    {loopInterval} min
                                </div>
                            </div>
                            <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
                                <div className="text-xs text-gray-500 dark:text-gray-400">Min Delay</div>
                                <div className="text-lg font-semibold text-gray-900 dark:text-white">
                                    {minDelay}s
                                </div>
                            </div>
                            <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-lg">
                                <div className="text-xs text-gray-500 dark:text-gray-400">Max Delay</div>
                                <div className="text-lg font-semibold text-gray-900 dark:text-white">
                                    {maxDelay}s
                                </div>
                            </div>
                        </div>

                        {/* Stats */}
                        <div className="grid grid-cols-2 gap-4">
                            <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                                <div className="text-xs text-gray-500 dark:text-gray-400">Next Broadcast</div>
                                <div className="text-xl font-bold text-green-600 dark:text-green-400 font-mono">
                                    {countdown || "Calculating..."}
                                </div>
                            </div>
                            <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                                <div className="text-xs text-gray-500 dark:text-gray-400">Messages Sent</div>
                                <div className="text-xl font-bold text-purple-600 dark:text-purple-400">
                                    {messagesSent}
                                </div>
                            </div>
                        </div>

                        {/* Actions */}
                        <div className="flex gap-2 pt-2">
                            <Button
                                variant="destructive"
                                onClick={() => {
                                    handleStopScheduler();
                                    setShowSchedulerDetails(false);
                                }}
                                className="flex-1"
                            >
                                <Pause className="h-4 w-4 mr-2" />
                                Stop Scheduler
                            </Button>
                            <Button
                                variant="outline"
                                onClick={() => setShowSchedulerDetails(false)}
                            >
                                Close
                            </Button>
                        </div>
                    </div>
                </DialogContent>
            </Dialog>
        </div>
    );
}
