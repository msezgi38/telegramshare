import { NextResponse } from "next/server";
import { getAccountGroups, addAccountGroup, getAccountById } from "@/lib/db";

export async function GET(
    request: Request,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const { id } = await params;
        const accountId = parseInt(id);
        if (isNaN(accountId)) {
            return NextResponse.json({ error: "Invalid account ID" }, { status: 400 });
        }

        const groups = await getAccountGroups(accountId);
        return NextResponse.json(groups);
    } catch (error) {
        console.error("Failed to get account groups:", error);
        return NextResponse.json(
            { error: "Failed to get account groups" },
            { status: 500 }
        );
    }
}

export async function POST(
    request: Request,
    { params }: { params: Promise<{ id: string }> }
) {
    try {
        const { id } = await params;
        const accountId = parseInt(id);
        if (isNaN(accountId)) {
            return NextResponse.json({ error: "Invalid account ID" }, { status: 400 });
        }

        const body = await request.json();
        const { groups } = body;

        if (!Array.isArray(groups)) {
            return NextResponse.json(
                { error: "Groups must be an array" },
                { status: 400 }
            );
        }

        const added = [];
        for (const group of groups) {
            const newGroup = await addAccountGroup({
                accountId,
                groupLink: group.link || group.groupLink,
                groupName: group.name || group.groupName,
                groupUsername: group.username || group.groupUsername,
                memberCount: group.memberCount || 0,
                joinedAt: group.joinedAt || new Date().toISOString(),
                messageCount: 0,
                status: "active",
            });
            added.push(newGroup);
        }

        return NextResponse.json({ success: true, count: added.length, groups: added });
    } catch (error) {
        console.error("Failed to add account groups:", error);
        return NextResponse.json(
            { error: "Failed to add account groups" },
            { status: 500 }
        );
    }
}
