import { GlassCard } from "@/components/ui/glass-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import Link from "next/link";
import { Apple, ArrowRight } from "lucide-react";

export default function LoginPage() {
    return (
        <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-gray-50 dark:bg-gray-950/50">
            {/* Abstract Background Gradients */}
            <div className="absolute top-[-20%] left-[-10%] h-[800px] w-[800px] rounded-full bg-blue-400/30 blur-[120px] mix-blend-multiply dark:bg-blue-900/40" />
            <div className="absolute top-[-20%] right-[-10%] h-[800px] w-[800px] rounded-full bg-purple-400/30 blur-[120px] mix-blend-multiply dark:bg-purple-900/40" />
            <div className="absolute bottom-[-20%] left-[20%] h-[800px] w-[800px] rounded-full bg-orange-400/30 blur-[120px] mix-blend-multiply dark:bg-orange-900/40" />

            {/* Main Container */}
            <div className="container relative z-10 mx-auto px-4">
                <GlassCard className="mx-auto max-w-md p-8 sm:p-12">
                    {/* Logo Section */}
                    <div className="mb-8 flex flex-col items-center justify-center text-center">
                        <div className="mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-tr from-blue-500 to-purple-600 shadow-lg text-white">
                            {/* Placeholder Icon */}
                            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-8 h-8">
                                <path d="M11.645 20.91l-.007-.003-.022-.012a15.247 15.247 0 01-.383-.218 25.18 25.18 0 01-4.244-3.17C4.688 15.36 2.25 12.174 2.25 8.25 2.25 5.322 4.714 3 7.688 3A5.5 5.5 0 0112 5.052 5.5 5.5 0 0116.313 3c2.973 0 5.437 2.322 5.437 5.25 0 3.925-2.438 7.111-4.739 9.256a25.175 25.175 0 01-4.244 3.17 15.247 15.247 0 01-.383.219l-.022.012-.007.004-.003.001a.752.752 0 01-.704 0l-.003-.001z" />
                            </svg>
                        </div>
                        <h1 className="text-2xl font-semibold tracking-tight text-gray-900 dark:text-white">
                            Sign in to Telegram Manager
                        </h1>
                        <p className="mt-2 text-sm text-gray-500 dark:text-gray-400">
                            Enter your credentials to access the dashboard
                        </p>
                    </div>

                    {/* Form Section */}
                    <div className="space-y-6">
                        <div className="space-y-2">
                            <Label htmlFor="email" className="text-gray-700 dark:text-gray-300">Email</Label>
                            <Input
                                id="email"
                                type="email"
                                placeholder="name@example.com"
                                className="h-11 rounded-xl border-gray-200 bg-white/50 backdrop-blur-sm focus:border-blue-500 focus:ring-blue-500/20 dark:border-white/10 dark:bg-white/5"
                            />
                        </div>
                        <div className="space-y-2">
                            <div className="flex items-center justify-between">
                                <Label htmlFor="password" className="text-gray-700 dark:text-gray-300">Password</Label>
                                <Link href="#" className="text-xs font-medium text-blue-600 hover:text-blue-500 dark:text-blue-400">
                                    Forgot password?
                                </Link>
                            </div>
                            <Input
                                id="password"
                                type="password"
                                className="h-11 rounded-xl border-gray-200 bg-white/50 backdrop-blur-sm focus:border-blue-500 focus:ring-blue-500/20 dark:border-white/10 dark:bg-white/5"
                            />
                        </div>

                        <Button className="h-11 w-full rounded-xl bg-blue-600 text-base font-medium shadow-lg hover:bg-blue-700 focus:ring-4 focus:ring-blue-500/20 dark:bg-blue-600 dark:hover:bg-blue-500">
                            Sign In
                            <ArrowRight className="ml-2 h-4 w-4" />
                        </Button>
                    </div>

                    {/* Footer Link */}
                    <div className="mt-8 flex flex-col items-center space-y-4 text-center">
                        <div className="text-sm text-gray-500 dark:text-gray-400">
                            Don&apos;t have an account?{" "}
                            <Link href="#" className="font-medium text-blue-600 hover:underline dark:text-blue-400">
                                Create Apple ID style account
                            </Link>
                        </div>
                        <div className="flex items-center text-xs text-gray-400">
                            <Apple className="mr-1 h-3 w-3" />
                            <span>Protected by Apple Systems</span>
                        </div>
                    </div>
                </GlassCard>
            </div>
        </div>
    );
}
